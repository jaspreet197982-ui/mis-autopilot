# MIS Autopilot 🚀
**AI-Powered Board-Ready Financial Commentary Generator**

Built with React + Vite + Claude AI

---

## Features
- ✅ 3-step guided workflow (Context → Data → Report)
- ✅ Live KPI dashboard (Revenue, EBITDA, PAT, Margins)
- ✅ Variance table with color-coded badges
- ✅ AI-generated CFO-grade commentary (8 sections)
- ✅ Interactive bar chart
- ✅ PDF export with branded layout
- ✅ CSV upload support

---

## Setup

### 1. Install dependencies
```bash
npm install
```

### 2. Run locally
```bash
npm run dev
```
Open http://localhost:3000

### 3. Build for production
```bash
npm run build
```

---

## Deploy on Vercel
1. Push code to GitHub
2. Go to vercel.com → New Project → Import GitHub repo
3. Vercel auto-detects Vite — click Deploy ✅

## Deploy on Replit
1. Create new Replit → Import from GitHub
2. Replit reads `.replit` config automatically
3. Click Run ▶️

---

## Project Structure
```
mis-autopilot/
├── index.html
├── vite.config.js
├── package.json
├── .replit
├── vercel.json
└── src/
    ├── main.jsx
    ├── App.jsx                  ← Main app (3 steps)
    ├── components/
    │   ├── StepNav.jsx          ← Progress navigation
    │   ├── KPIBar.jsx           ← KPI cards
    │   ├── VarianceTable.jsx    ← Data table
    │   ├── Commentary.jsx       ← AI report renderer
    │   └── DataChart.jsx        ← Bar chart
    └── lib/
        ├── utils.js             ← Helpers + AI prompt builder
        └── pdf.js               ← PDF export
```

---

## CSV Format
```
Line Item,Actual,Budget,Prior Year
Revenue from Operations,61896,59144,51468
Other Income,791,712,647
Cost of Materials,25348,25313,22840
```

---

Built by Jaspreet | M.Com — DAV University Jalandhar
