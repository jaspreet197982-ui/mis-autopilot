export default function StepNav({ step, setStep }) {
  const steps = [
    { n: 1, label: 'Context' },
    { n: 2, label: 'Data' },
    { n: 3, label: 'Report' },
  ]

  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      {steps.map((s, i) => {
        const done   = step > s.n
        const active = step === s.n
        return (
          <div key={s.n} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <button
              onClick={() => done && setStep(s.n)}
              style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '7px 16px', borderRadius: 30, border: 'none',
                background: done ? '#10b981' : active ? 'linear-gradient(135deg,#3b82f6,#6366f1)' : 'rgba(255,255,255,0.06)',
                color: done || active ? '#fff' : '#64748b',
                fontWeight: 600, fontSize: 12, cursor: done ? 'pointer' : 'default',
                fontFamily: "'DM Sans', sans-serif",
                transition: 'all 0.25s',
                boxShadow: active ? '0 0 20px rgba(99,102,241,0.4)' : 'none',
              }}
            >
              <span style={{
                width: 20, height: 20, borderRadius: '50%',
                background: done || active ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.08)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 800,
              }}>
                {done ? '✓' : s.n}
              </span>
              {s.label}
            </button>
            {i < steps.length - 1 && (
              <div style={{ width: 24, height: 1, background: done ? '#10b981' : 'rgba(255,255,255,0.1)' }} />
            )}
          </div>
        )
      })}
    </div>
  )
}
