export default function Commentary({ text }) {
  if (!text) return (
    <div style={{ textAlign: 'center', padding: '60px 20px', color: '#334155' }}>
      <div style={{ fontSize: 48, marginBottom: 16 }}>📋</div>
      <div style={{ fontSize: 16, fontWeight: 600, color: '#64748b' }}>No commentary yet</div>
      <div style={{ fontSize: 13, color: '#475569', marginTop: 4 }}>Generate your report to see AI-powered commentary here</div>
    </div>
  )

  const lines = text.split('\n')
  const elements = []
  let bulletBuffer = []

  const flushBullets = () => {
    if (bulletBuffer.length) {
      elements.push(
        <ul key={`ul-${elements.length}`} style={{ paddingLeft: 0, margin: '8px 0 16px 0', listStyle: 'none' }}>
          {bulletBuffer.map((b, i) => (
            <li key={i} style={{
              display: 'flex', gap: 10, alignItems: 'flex-start',
              padding: '6px 0', borderBottom: '1px solid rgba(255,255,255,0.04)',
              color: '#94a3b8', fontSize: 14, lineHeight: 1.75,
            }}>
              <span style={{ color: '#3b82f6', marginTop: 2, flexShrink: 0 }}>◆</span>
              <span>{b}</span>
            </li>
          ))}
        </ul>
      )
      bulletBuffer = []
    }
  }

  lines.forEach((line, i) => {
    if (line.startsWith('## ')) {
      flushBullets()
      const title = line.replace('## ', '')
      elements.push(
        <div key={i} style={{
          display: 'flex', alignItems: 'center', gap: 12,
          margin: '28px 0 12px 0', paddingBottom: 10,
          borderBottom: '1px solid rgba(59,130,246,0.2)',
        }}>
          <div style={{ width: 3, height: 20, background: 'linear-gradient(180deg,#3b82f6,#6366f1)', borderRadius: 2, flexShrink: 0 }} />
          <h3 style={{
            fontSize: 13, fontWeight: 700, color: '#93c5fd',
            textTransform: 'uppercase', letterSpacing: '1.5px',
            fontFamily: "'DM Sans', sans-serif",
          }}>{title}</h3>
        </div>
      )
    } else if (line.startsWith('• ') || line.startsWith('- ')) {
      bulletBuffer.push(line.replace(/^[•\-] /, ''))
    } else if (line.trim() === '') {
      flushBullets()
      elements.push(<div key={i} style={{ height: 6 }} />)
    } else {
      flushBullets()
      elements.push(
        <p key={i} style={{
          color: '#94a3b8', fontSize: 14, lineHeight: 1.85,
          margin: '4px 0', textAlign: 'justify',
        }}>{line}</p>
      )
    }
  })

  flushBullets()

  return <div style={{ padding: '8px 0' }}>{elements}</div>
}
