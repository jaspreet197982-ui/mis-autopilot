import { deriveKPIs } from '../lib/utils.js'

function KPICard({ label, value, suffix, color, isPercent }) {
  const display = value == null ? '—'
    : isPercent ? `${value.toFixed(1)}%`
    : `₹${Math.abs(value).toLocaleString('en-IN', { maximumFractionDigits: 0 })} Cr`

  return (
    <div style={{
      background: 'rgba(255,255,255,0.04)', borderRadius: 14,
      padding: '16px 18px', borderTop: `3px solid ${color}`,
      backdropFilter: 'blur(8px)', flex: 1, minWidth: 0,
      transition: 'transform 0.2s',
    }}>
      <div style={{ fontSize: 10, fontWeight: 700, color: '#64748b', textTransform: 'uppercase', letterSpacing: '0.8px', marginBottom: 8 }}>
        {label}
      </div>
      <div style={{ fontSize: 20, fontWeight: 700, color, letterSpacing: '-0.5px' }}>
        {display}
      </div>
    </div>
  )
}

export default function KPIBar({ rows, currency }) {
  const k = deriveKPIs(rows)

  const items = [
    { label: 'Revenue',       value: k.rev,    color: '#3b82f6' },
    { label: 'EBITDA',        value: k.ebitda, color: '#8b5cf6' },
    { label: 'PAT',           value: k.pat,    color: '#10b981' },
    { label: 'EBITDA Margin', value: k.ebitdaM,color: '#f59e0b', isPercent: true },
    { label: 'PAT Margin',    value: k.patM,   color: '#ef4444', isPercent: true },
  ]

  if (!items.some(i => i.value != null)) return null

  return (
    <div style={{ display: 'flex', gap: 12, marginBottom: 24, flexWrap: 'wrap' }}>
      {items.map(item => <KPICard key={item.label} {...item} currency={currency} />)}
    </div>
  )
}
