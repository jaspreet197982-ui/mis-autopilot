import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { parseNum } from '../lib/utils.js'

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div style={{ background: '#0f1623', border: '1px solid rgba(59,130,246,0.3)', borderRadius: 10, padding: '10px 14px', fontSize: 12 }}>
      <div style={{ color: '#93c5fd', fontWeight: 700, marginBottom: 6 }}>{label}</div>
      {payload.map(p => (
        <div key={p.name} style={{ color: p.color, marginBottom: 2 }}>
          {p.name}: ₹{p.value?.toLocaleString('en-IN', { maximumFractionDigits: 1 })} Cr
        </div>
      ))}
    </div>
  )
}

export default function DataChart({ rows }) {
  const data = rows
    .filter(r => r.label && (parseNum(r.actual) != null || parseNum(r.budget) != null || parseNum(r.prior) != null))
    .slice(0, 8)
    .map(r => ({
      name: r.label.length > 18 ? r.label.slice(0, 16) + '…' : r.label,
      Actual: parseNum(r.actual),
      Budget: parseNum(r.budget),
      'Prior Year': parseNum(r.prior),
    }))

  if (!data.length) return (
    <div style={{ textAlign: 'center', padding: 40, color: '#475569' }}>Enter data to see chart</div>
  )

  return (
    <div style={{ width: '100%', height: 320 }}>
      <ResponsiveContainer>
        <BarChart data={data} margin={{ top: 10, right: 20, left: 10, bottom: 60 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
          <XAxis dataKey="name" tick={{ fill: '#64748b', fontSize: 10 }} angle={-35} textAnchor="end" interval={0} />
          <YAxis tick={{ fill: '#64748b', fontSize: 10 }} tickFormatter={v => `₹${(v/1000).toFixed(0)}k`} />
          <Tooltip content={<CustomTooltip />} />
          <Legend wrapperStyle={{ color: '#94a3b8', fontSize: 12, paddingTop: 16 }} />
          <Bar dataKey="Actual"     fill="#3b82f6" radius={[4,4,0,0]} maxBarSize={28} />
          <Bar dataKey="Budget"     fill="#6366f1" radius={[4,4,0,0]} maxBarSize={28} />
          <Bar dataKey="Prior Year" fill="#10b981" radius={[4,4,0,0]} maxBarSize={28} />
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}
