import { parseNum, varPct, fmtINR } from '../lib/utils.js'

function VarBadge({ actual, base }) {
  const pct = varPct(actual, base)
  if (pct == null) return <span style={{ color: '#475569' }}>—</span>
  const pos = pct >= 0
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 4,
      color: pos ? '#10b981' : '#f43f5e',
      fontWeight: 700, fontSize: 12,
      background: pos ? 'rgba(16,185,129,0.1)' : 'rgba(244,63,94,0.1)',
      padding: '2px 8px', borderRadius: 20,
    }}>
      {pos ? '▲' : '▼'} {pos ? '+' : ''}{pct.toFixed(1)}%
    </span>
  )
}

const TH = ({ children, right }) => (
  <th style={{
    padding: '11px 14px', background: 'rgba(255,255,255,0.04)',
    color: '#64748b', fontSize: 11, fontWeight: 700,
    textAlign: right ? 'right' : 'left',
    textTransform: 'uppercase', letterSpacing: '0.5px',
    borderBottom: '1px solid rgba(255,255,255,0.06)',
    whiteSpace: 'nowrap',
  }}>{children}</th>
)

export default function VarianceTable({ rows, currency }) {
  return (
    <div style={{ overflowX: 'auto' }}>
      <table style={{ width: '100%', borderCollapse: 'collapse' }}>
        <thead>
          <tr>
            <TH>Line Item</TH>
            <TH right>Actual</TH>
            <TH right>Budget</TH>
            <TH right>Prior Year</TH>
            <TH right>Var vs Budget</TH>
            <TH right>Var vs Prior</TH>
          </tr>
        </thead>
        <tbody>
          {rows.filter(r => r.label).map((row, i) => {
            const a = parseNum(row.actual)
            const b = parseNum(row.budget)
            const p = parseNum(row.prior)
            return (
              <tr key={row.id} style={{ background: i % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.02)' }}>
                <td style={{ padding: '11px 14px', fontWeight: 600, color: '#e2e8f0', fontSize: 13, borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  {row.label}
                </td>
                {[a, b, p].map((val, vi) => (
                  <td key={vi} style={{ padding: '11px 14px', textAlign: 'right', color: vi === 0 ? '#f1f5f9' : '#64748b', fontWeight: vi === 0 ? 600 : 400, fontSize: 13, borderBottom: '1px solid rgba(255,255,255,0.04)', fontVariantNumeric: 'tabular-nums' }}>
                    {val != null ? fmtINR(val) : '—'}
                  </td>
                ))}
                <td style={{ padding: '11px 14px', textAlign: 'right', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  {a != null && b != null ? <VarBadge actual={a} base={b} /> : '—'}
                </td>
                <td style={{ padding: '11px 14px', textAlign: 'right', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                  {a != null && p != null ? <VarBadge actual={a} base={p} /> : '—'}
                </td>
              </tr>
            )
          })}
        </tbody>
      </table>
    </div>
  )
}
