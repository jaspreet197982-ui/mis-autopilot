import { useState, useRef, useCallback } from 'react'
import StepNav from './components/StepNav.jsx'
import KPIBar from './components/KPIBar.jsx'
import VarianceTable from './components/VarianceTable.jsx'
import Commentary from './components/Commentary.jsx'
import DataChart from './components/DataChart.jsx'
import { buildPrompt, parseNum, varPct } from './lib/utils.js'
import { exportPDF } from './lib/pdf.js'

// ── Default rows ─────────────────────────────────────────────────────────────
const DEFAULT_ROWS = [
  { id: 1,  label: 'Revenue from Operations', actual: '', budget: '', prior: '' },
  { id: 2,  label: 'Other Income',             actual: '', budget: '', prior: '' },
  { id: 3,  label: 'Cost of Materials',        actual: '', budget: '', prior: '' },
  { id: 4,  label: 'Employee Benefit Expense', actual: '', budget: '', prior: '' },
  { id: 5,  label: 'Advertising & Promotion',  actual: '', budget: '', prior: '' },
  { id: 6,  label: 'Other Expenses',           actual: '', budget: '', prior: '' },
  { id: 7,  label: 'Depreciation',             actual: '', budget: '', prior: '' },
  { id: 8,  label: 'Finance Costs',            actual: '', budget: '', prior: '' },
  { id: 9,  label: 'Tax Expense',              actual: '', budget: '', prior: '' },
]

// ── Shared UI primitives ─────────────────────────────────────────────────────
const card = {
  background: 'rgba(255,255,255,0.04)',
  borderRadius: 16,
  border: '1px solid rgba(255,255,255,0.07)',
  padding: 28,
  marginBottom: 20,
  backdropFilter: 'blur(12px)',
}

const inputStyle = {
  width: '100%', padding: '11px 14px',
  background: 'rgba(255,255,255,0.05)',
  border: '1.5px solid rgba(255,255,255,0.1)',
  borderRadius: 10, color: '#e2e8f0', fontSize: 14,
  outline: 'none', fontFamily: "'DM Sans', sans-serif",
  transition: 'border 0.2s',
}

function Label({ children }) {
  return (
    <label style={{ display: 'block', fontSize: 11, fontWeight: 700, color: '#64748b', marginBottom: 6, textTransform: 'uppercase', letterSpacing: '0.6px' }}>
      {children}
    </label>
  )
}

function Btn({ children, onClick, variant = 'primary', disabled, style = {} }) {
  const styles = {
    primary: { background: 'linear-gradient(135deg,#3b82f6,#6366f1)', color: '#fff', boxShadow: '0 4px 20px rgba(99,102,241,0.35)' },
    ghost:   { background: 'rgba(255,255,255,0.07)', color: '#94a3b8', border: '1px solid rgba(255,255,255,0.1)' },
    danger:  { background: 'rgba(239,68,68,0.1)', color: '#f87171', border: '1px solid rgba(239,68,68,0.2)' },
    success: { background: 'linear-gradient(135deg,#059669,#10b981)', color: '#fff', boxShadow: '0 4px 20px rgba(16,185,129,0.3)' },
  }
  return (
    <button onClick={onClick} disabled={disabled} style={{
      padding: '11px 24px', borderRadius: 10, border: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer', fontWeight: 600, fontSize: 14,
      fontFamily: "'DM Sans', sans-serif", transition: 'all 0.2s',
      opacity: disabled ? 0.6 : 1, ...styles[variant], ...style,
    }}>
      {children}
    </button>
  )
}

// ── Step 1: Context ──────────────────────────────────────────────────────────
function StepContext({ ctx, setCtx, onNext, error }) {
  const fields = [
    { key: 'company',     label: 'Company Name',         ph: 'e.g. Hindustan Unilever Limited', full: true },
    { key: 'period',      label: 'Period',                ph: 'e.g. FY 2024' },
    { key: 'priorPeriod', label: 'Prior Period (optional)', ph: 'e.g. FY 2023' },
    { key: 'industry',    label: 'Industry',              ph: 'e.g. FMCG' },
    { key: 'currency',    label: 'Currency / Scale',      ph: 'e.g. INR Cr' },
  ]

  return (
    <div style={{ animation: 'fadeUp 0.4s ease' }}>
      <div style={{ marginBottom: 32 }}>
        <h1 style={{ fontSize: 32, fontWeight: 700, color: '#f1f5f9', fontFamily: "'Fraunces', serif", marginBottom: 8, letterSpacing: '-0.5px' }}>
          Report Context
        </h1>
        <p style={{ color: '#64748b', fontSize: 15 }}>Set up your MIS report parameters. This appears on the final board report.</p>
      </div>

      <div style={card}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
          {fields.map(f => (
            <div key={f.key} style={f.full ? { gridColumn: '1 / -1' } : {}}>
              <Label>{f.label}</Label>
              <input
                style={inputStyle}
                placeholder={f.ph}
                value={ctx[f.key]}
                onChange={e => setCtx(c => ({ ...c, [f.key]: e.target.value }))}
                onFocus={e => e.target.style.borderColor = '#3b82f6'}
                onBlur={e => e.target.style.borderColor = 'rgba(255,255,255,0.1)'}
              />
            </div>
          ))}
        </div>
      </div>

      {error && <div style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 10, padding: '12px 16px', color: '#f87171', fontSize: 13, marginBottom: 16 }}>⚠ {error}</div>}

      <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
        <Btn onClick={onNext}>Continue to Financial Data →</Btn>
      </div>
    </div>
  )
}

// ── Step 2: Data Entry ───────────────────────────────────────────────────────
function StepData({ ctx, rows, setRows, onBack, onGenerate, loading, error }) {
  const fileRef = useRef()
  const activeTab = useState('table')[0]

  const updateRow = useCallback((id, field, val) =>
    setRows(r => r.map(row => row.id === id ? { ...row, [field]: val } : row)), [setRows])

  const addRow = () =>
    setRows(r => [...r, { id: Date.now(), label: '', actual: '', budget: '', prior: '' }])

  const removeRow = (id) =>
    setRows(r => r.filter(row => row.id !== id))

  const handleCSV = (e) => {
    const file = e.target.files[0]
    if (!file) return
    const reader = new FileReader()
    reader.onload = (ev) => {
      const lines = ev.target.result.split('\n').filter(Boolean)
      const parsed = lines.slice(1).map((line, i) => {
        const cols = line.split(',')
        return { id: i + 1, label: cols[0]?.trim() || '', actual: cols[1]?.trim() || '', budget: cols[2]?.trim() || '', prior: cols[3]?.trim() || '' }
      }).filter(r => r.label)
      if (parsed.length) setRows(parsed)
    }
    reader.readAsText(file)
    e.target.value = ''
  }

  return (
    <div style={{ animation: 'fadeUp 0.4s ease' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 28 }}>
        <div>
          <h1 style={{ fontSize: 32, fontWeight: 700, color: '#f1f5f9', fontFamily: "'Fraunces', serif", marginBottom: 8, letterSpacing: '-0.5px' }}>
            Financial Data
          </h1>
          <p style={{ color: '#64748b', fontSize: 15 }}>Enter figures in {ctx.currency}. All columns optional except Actual.</p>
        </div>
        <div style={{ display: 'flex', gap: 10, flexShrink: 0 }}>
          <input ref={fileRef} type="file" accept=".csv" style={{ display: 'none' }} onChange={handleCSV} />
          <Btn variant="ghost" onClick={() => fileRef.current.click()} style={{ padding: '9px 18px', fontSize: 13 }}>⬆ CSV</Btn>
          <Btn variant="ghost" onClick={addRow} style={{ padding: '9px 18px', fontSize: 13 }}>+ Add Row</Btn>
        </div>
      </div>

      <KPIBar rows={rows} currency={ctx.currency} />

      <div style={card}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              {['Line Item', 'Actual', 'Budget', 'Prior Year', 'Var vs Budget', 'Var vs Prior', ''].map((h, i) => (
                <th key={i} style={{ padding: '10px 12px', background: 'rgba(255,255,255,0.04)', color: '#475569', fontSize: 11, fontWeight: 700, textAlign: i === 0 ? 'left' : 'right', textTransform: 'uppercase', letterSpacing: '0.5px', borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row, idx) => {
              const a = parseNum(row.actual), b = parseNum(row.budget), p = parseNum(row.prior)
              const vb = a != null && b != null ? varPct(a, b) : null
              const vp = a != null && p != null ? varPct(a, p) : null
              return (
                <tr key={row.id} style={{ background: idx % 2 === 0 ? 'transparent' : 'rgba(255,255,255,0.015)' }}>
                  <td style={{ padding: '8px 10px', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                    <input
                      style={{ ...inputStyle, background: 'transparent', border: 'none', padding: '4px 2px', fontWeight: 500 }}
                      value={row.label}
                      onChange={e => updateRow(row.id, 'label', e.target.value)}
                      placeholder="Line item…"
                    />
                  </td>
                  {['actual', 'budget', 'prior'].map(f => (
                    <td key={f} style={{ padding: '8px 6px', borderBottom: '1px solid rgba(255,255,255,0.04)' }}>
                      <input
                        style={{ ...inputStyle, textAlign: 'right', width: 110, padding: '7px 10px', fontSize: 13 }}
                        value={row[f]}
                        onChange={e => updateRow(row.id, f, e.target.value)}
                        placeholder="—"
                      />
                    </td>
                  ))}
                  <td style={{ padding: '8px 12px', textAlign: 'right', borderBottom: '1px solid rgba(255,255,255,0.04)', fontSize: 12, fontWeight: 700, color: vb == null ? '#475569' : vb >= 0 ? '#10b981' : '#f43f5e' }}>
                    {vb != null ? `${vb >= 0 ? '▲ +' : '▼ '}${vb.toFixed(1)}%` : '—'}
                  </td>
                  <td style={{ padding: '8px 12px', textAlign: 'right', borderBottom: '1px solid rgba(255,255,255,0.04)', fontSize: 12, fontWeight: 700, color: vp == null ? '#475569' : vp >= 0 ? '#10b981' : '#f43f5e' }}>
                    {vp != null ? `${vp >= 0 ? '▲ +' : '▼ '}${vp.toFixed(1)}%` : '—'}
                  </td>
                  <td style={{ padding: '8px 10px', borderBottom: '1px solid rgba(255,255,255,0.04)', textAlign: 'center' }}>
                    <button onClick={() => removeRow(row.id)} style={{ background: 'none', border: 'none', color: '#475569', cursor: 'pointer', fontSize: 16, padding: '2px 6px', borderRadius: 6, transition: 'color 0.2s' }}
                      onMouseEnter={e => e.target.style.color = '#f43f5e'}
                      onMouseLeave={e => e.target.style.color = '#475569'}>✕</button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
        <div style={{ marginTop: 12, fontSize: 11, color: '#334155' }}>
          💡 CSV format: Line Item, Actual, Budget, Prior Year (first row = headers)
        </div>
      </div>

      {error && <div style={{ background: 'rgba(239,68,68,0.1)', border: '1px solid rgba(239,68,68,0.3)', borderRadius: 10, padding: '12px 16px', color: '#f87171', fontSize: 13, marginBottom: 16 }}>⚠ {error}</div>}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <Btn variant="ghost" onClick={onBack}>← Back</Btn>
        <Btn onClick={onGenerate} disabled={loading} style={{ minWidth: 220, justifyContent: 'center', display: 'flex', alignItems: 'center', gap: 10 }}>
          {loading
            ? <><span style={{ width: 16, height: 16, border: '2px solid rgba(255,255,255,0.3)', borderTop: '2px solid #fff', borderRadius: '50%', animation: 'spin 0.7s linear infinite', display: 'inline-block' }} /> Generating…</>
            : '✨ Generate MIS Commentary'}
        </Btn>
      </div>
    </div>
  )
}

// ── Step 3: Report ───────────────────────────────────────────────────────────
function StepReport({ ctx, rows, report, onBack, onRegenerate, loading, onExportPDF }) {
  const [tab, setTab] = useState('commentary')

  const tabs = [
    { id: 'commentary', label: '📝 Commentary' },
    { id: 'table',      label: '📊 Variance Table' },
    { id: 'chart',      label: '📈 Chart' },
  ]

  return (
    <div style={{ animation: 'fadeUp 0.4s ease' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
        <div>
          <h1 style={{ fontSize: 32, fontWeight: 700, color: '#f1f5f9', fontFamily: "'Fraunces', serif", marginBottom: 6, letterSpacing: '-0.5px' }}>
            MIS Commentary Report
          </h1>
          <p style={{ color: '#64748b', fontSize: 14 }}>
            {ctx.company} · {ctx.period}{ctx.priorPeriod ? ` vs ${ctx.priorPeriod}` : ''} · {ctx.industry || 'General'} · {ctx.currency}
          </p>
        </div>
        <div style={{ display: 'flex', gap: 10, flexShrink: 0 }}>
          <Btn variant="ghost" onClick={onBack} style={{ padding: '9px 16px', fontSize: 13 }}>← Edit</Btn>
          <Btn variant="ghost" onClick={onRegenerate} disabled={loading} style={{ padding: '9px 16px', fontSize: 13 }}>
            {loading ? '…' : '↻ Regenerate'}
          </Btn>
          <Btn variant="success" onClick={onExportPDF} style={{ padding: '9px 18px', fontSize: 13 }}>⬇ Export PDF</Btn>
        </div>
      </div>

      <KPIBar rows={rows} currency={ctx.currency} />

      <div style={card}>
        {/* Tab bar */}
        <div style={{ display: 'flex', gap: 4, marginBottom: 20, borderBottom: '1px solid rgba(255,255,255,0.07)', paddingBottom: 16 }}>
          {tabs.map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} style={{
              padding: '8px 18px', borderRadius: 8, border: 'none',
              background: tab === t.id ? 'rgba(59,130,246,0.2)' : 'transparent',
              color: tab === t.id ? '#93c5fd' : '#64748b',
              fontWeight: 600, fontSize: 13, cursor: 'pointer',
              fontFamily: "'DM Sans', sans-serif",
              borderBottom: tab === t.id ? '2px solid #3b82f6' : '2px solid transparent',
              transition: 'all 0.2s',
            }}>{t.label}</button>
          ))}
        </div>

        {tab === 'commentary' && <Commentary text={report} />}
        {tab === 'table'      && <VarianceTable rows={rows} currency={ctx.currency} />}
        {tab === 'chart'      && <DataChart rows={rows} />}
      </div>

      <div style={{ background: 'rgba(16,185,129,0.08)', border: '1px solid rgba(16,185,129,0.2)', borderRadius: 12, padding: '12px 18px', display: 'flex', alignItems: 'center', gap: 10, fontSize: 12, color: '#6ee7b7' }}>
        <span>✅</span>
        <span>Generated by MIS Autopilot · {new Date().toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })} · Confidential — For Board Use Only</span>
      </div>
    </div>
  )
}

// ── Root App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [step, setStep]     = useState(1)
  const [ctx, setCtx]       = useState({ company: '', period: '', priorPeriod: '', industry: '', currency: 'INR Cr' })
  const [rows, setRows]     = useState(DEFAULT_ROWS)
  const [report, setReport] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError]   = useState('')

  const generate = async () => {
    if (!ctx.company || !ctx.period) { setError('Company Name and Period are required.'); return }
    setError(''); setLoading(true); setReport('')
    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-20250514',
          max_tokens: 1000,
          messages: [{ role: 'user', content: buildPrompt(ctx, rows) }],
        }),
      })
      const data = await res.json()
      const text = data.content?.map(b => b.text || '').join('') || ''
      setReport(text)
      setStep(3)
    } catch {
      setError('Failed to generate commentary. Please check your connection and try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleExportPDF = () => {
    if (!report) { alert('Please generate commentary first.'); return }
    exportPDF(ctx, rows, report)
  }

  return (
    <div style={{ minHeight: '100vh', background: '#080c14' }}>
      <style>{`
        @keyframes fadeUp { from { opacity:0; transform:translateY(16px) } to { opacity:1; transform:translateY(0) } }
        @keyframes spin { to { transform: rotate(360deg) } }
        input::placeholder { color: #334155 }
      `}</style>

      {/* Background grid pattern */}
      <div style={{ position: 'fixed', inset: 0, backgroundImage: 'radial-gradient(rgba(59,130,246,0.07) 1px, transparent 1px)', backgroundSize: '32px 32px', pointerEvents: 'none' }} />

      {/* Glow orbs */}
      <div style={{ position: 'fixed', top: -200, left: -200, width: 600, height: 600, background: 'radial-gradient(circle, rgba(59,130,246,0.08) 0%, transparent 70%)', pointerEvents: 'none' }} />
      <div style={{ position: 'fixed', bottom: -200, right: -200, width: 500, height: 500, background: 'radial-gradient(circle, rgba(99,102,241,0.08) 0%, transparent 70%)', pointerEvents: 'none' }} />

      {/* NAV */}
      <nav style={{ background: 'rgba(8,12,20,0.9)', backdropFilter: 'blur(20px)', borderBottom: '1px solid rgba(255,255,255,0.06)', padding: '0 32px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: 64, position: 'sticky', top: 0, zIndex: 100 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <div style={{ width: 36, height: 36, background: 'linear-gradient(135deg,#3b82f6,#6366f1)', borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 16, fontWeight: 900, color: '#fff', boxShadow: '0 0 20px rgba(99,102,241,0.4)' }}>M</div>
          <div>
            <div style={{ color: '#f1f5f9', fontWeight: 700, fontSize: 17, letterSpacing: '-0.3px', fontFamily: "'Fraunces', serif" }}>MIS Autopilot</div>
            <div style={{ color: '#334155', fontSize: 11, letterSpacing: '0.5px' }}>AI-POWERED BOARD COMMENTARY</div>
          </div>
        </div>
        <StepNav step={step} setStep={setStep} />
        <div style={{ fontSize: 12, color: '#1e3a5f', fontWeight: 600 }}>v1.0</div>
      </nav>

      <main style={{ maxWidth: 1100, margin: '0 auto', padding: '40px 24px', position: 'relative' }}>
        {step === 1 && <StepContext ctx={ctx} setCtx={setCtx} onNext={() => { if (!ctx.company || !ctx.period) { setError('Company name and period are required.'); return } setError(''); setStep(2) }} error={error} />}
        {step === 2 && <StepData ctx={ctx} rows={rows} setRows={setRows} onBack={() => setStep(1)} onGenerate={generate} loading={loading} error={error} />}
        {step === 3 && <StepReport ctx={ctx} rows={rows} report={report} onBack={() => setStep(2)} onRegenerate={generate} loading={loading} onExportPDF={handleExportPDF} />}
      </main>
    </div>
  )
}
